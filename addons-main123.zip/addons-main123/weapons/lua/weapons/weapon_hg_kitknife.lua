SWEP.Base = "weapon_hg_melee_base"

SWEP.PrintName = "Kitchen knife"
SWEP.Category = "[HG] Melee"
SWEP.Instructions = ""

SWEP.Spawnable= true
SWEP.AdminSpawnable= true
SWEP.AdminOnly = false

SWEP.ViewModelFOV = 60
SWEP.ViewModel = "models/weapons/me_kitknife/w_me_kitknife.mdl"
SWEP.WorldModel = "models/weapons/me_kitknife/w_me_kitknife.mdl"
SWEP.ViewModelFlip = false

SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.Slot = 1
SWEP.SlotPos = 2

SWEP.UseHands = true

---SWEP.HoldType = "knife"

SWEP.FiresUnderwater = false

SWEP.DrawCrosshair = false

SWEP.DrawAmmo = true

SWEP.Primary.Damage = 10
SWEP.Primary.Ammo = "none"
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Recoil = 0.5
SWEP.Primary.Delay = 0.7
SWEP.Primary.Force = 60

SWEP.Secondary.ClipSize = 0
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawSound = "snd_jack_hmcd_knifedraw.wav"
SWEP.HitSound = "snd_jack_hmcd_knifehit.wav"
SWEP.FlashHitSound = "snd_jack_hmcd_slash.wav"
SWEP.ShouldDecal = true
SWEP.HoldTypeWep = "knife"
SWEP.DamageType = DMG_SLASH

SWEP.IconPos = { Pos = Vector(22.45, 3, -4), Ang = Angle(-100.00, 0.00, -2.45), FOV = 60.69 }